/*
 *******************************************************************************
 * Project:       bdb_puzzle
 * Description:   blank.
 * Author:        103
 *                hf0bae103@hotmail.com
 * File:          main.c
 * Processor:     blank.
 * IDE:           CodeBlocks 16.01
 * Version:       170303t1418
 * Notes:         blank.
 *******************************************************************************
*/

#include "main.h"

BDB_PUZZLE_t bdb_puzzle_t;
BDB_PUZZLE_TASK_t bdb_puzzle_task_t[BDB_PUZZLE_TASK_t_MAX];

static void bdb_puzzle(void);
static void bdb_puzzle_task_insert(void (*function)(int, int), unsigned int stay, int parameter_1, int parameter_2);
static unsigned int bdb_puzzle_task_clear(unsigned int count);
static void task_1(int parameter_1, int parameter_2);
static void task_2(int parameter_1, int parameter_2);
static void task_3(int parameter_1, int parameter_2);

int main()
{
    bdb_puzzle_task_insert(task_1, 10, -10, 10);
    bdb_puzzle_task_insert(task_2, 100, -100, 100);
    bdb_puzzle_task_insert(task_3, 1000, -1000, 1000);

    for(;;)
    {
        bdb_puzzle();

        bdb_puzzle_t.tick++;
    }

    return 0;
}

/*
 * bdb_puzzle()
 * Description:   blank.
 * Parameter:     none.
 * Return:        none.
 * Notes:         blank.
*/
static void bdb_puzzle(void)
{
    unsigned int flag;
    unsigned int now = 0;
    unsigned int stay = 0;

    bdb_puzzle_task_t[bdb_puzzle_t.count].id != 0 ? flag = 1 : (flag = 0);

    if(flag == 1)
    {
        now = bdb_puzzle_t.tick;

        if(now > bdb_puzzle_task_t[bdb_puzzle_t.count].now)
        {
            stay = now - bdb_puzzle_task_t[bdb_puzzle_t.count].now;
        }
        else
        {
            stay = bdb_puzzle_task_t[bdb_puzzle_t.count].now - now;
        }

        if(stay >= bdb_puzzle_task_t[bdb_puzzle_t.count].stay)
        {
            bdb_puzzle_task_t[bdb_puzzle_t.count].function(bdb_puzzle_task_t[bdb_puzzle_t.count].parameter_1, bdb_puzzle_task_t[bdb_puzzle_t.count].parameter_2);

            bdb_puzzle_t.return_id = bdb_puzzle_task_clear(bdb_puzzle_t.count);
        }
    }

# if 0
// 2016�� 10�� 20��
// STM32F407VGT7���� ���� ���� �� ������
    bdb_puzzle_t.count >= BDB_PUZZLE_TASK_t_MAX ? bdb_puzzle_t.count = 0 : bdb_puzzle_t.count++;
# else
// 2016�� 10�� 20��
// STM32F407VGT7���� ���� ���� �� ���� ����
    bdb_puzzle_t.count++;

    if(bdb_puzzle_t.count >= BDB_PUZZLE_TASK_t_MAX)
    {
            bdb_puzzle_t.count = 0;
    }
#endif
}

/*
 * bdb_puzzle_task_insert()
 * Description:   blank.
 * Parameter:     none.
 * Return:        none.
 * Notes:         blank.
*/
static void bdb_puzzle_task_insert(void (*function)(int, int), unsigned int stay, int parameter_1, int parameter_2)
{
    unsigned int count;

    for(count = 1; count < BDB_PUZZLE_TASK_t_MAX; count++)
    {
        if(bdb_puzzle_task_t[count].id == 0)
        {
            break;
        }
    }

    bdb_puzzle_task_t[count].id = count;
    bdb_puzzle_task_t[count].function = function;
    bdb_puzzle_task_t[count].now = bdb_puzzle_t.tick;
    bdb_puzzle_task_t[count].stay = stay;
    bdb_puzzle_task_t[count].parameter_1 = parameter_1;
    bdb_puzzle_task_t[count].parameter_2 = parameter_2;
}

/*
 * bdb_puzzle_task_clear()
 * Description:   blank.
 * Parameter:     none.
 * Return:        none.
 * Notes:         blank.
*/
static unsigned int bdb_puzzle_task_clear(unsigned int count)
{
    bdb_puzzle_task_t[count].id = 0;
    bdb_puzzle_task_t[count].function = 0;
    bdb_puzzle_task_t[count].now = 0;
    bdb_puzzle_task_t[count].stay = 0;
    bdb_puzzle_task_t[count].parameter_1 = 0;
    bdb_puzzle_task_t[count].parameter_2 = 0;

    return count;
}

/*
 * task_1()
 * Description:   blank.
 * Parameter:     none.
 * Return:        none.
 * Notes:         blank.
*/
static void task_1(int parameter_1, int parameter_2)
{
    printf("task_1, %d, %d\n\r", parameter_1, parameter_2);
}

/*
 * task_2()
 * Description:   blank.
 * Parameter:     none.
 * Return:        none.
 * Notes:         blank.
*/
static void task_2(int parameter_1, int parameter_2)
{
    printf("task_2, %d, %d\n\r", parameter_1, parameter_2);
}

/*
 * task_3()
 * Description:   blank.
 * Parameter:     none.
 * Return:        none.
 * Notes:         blank.
*/
static void task_3(int parameter_1, int parameter_2)
{
    printf("task_3, %d, %d\n\r", parameter_1, parameter_2);
}

/* END OF FILE ****************************************************************/

